
#define MYSERVO 0   
#include <delayms.c>
#include <digitalp.c>
#include <digitalt.c>
#include <servos.c>
#include <typedef.h>
#include <analog.c>
